// Non-strict Function allows duplicate parameter names and implicit global assignment.
const nonStrictDemo = Function("a", "a", "total = 10; return total;");
try { console.log("Non-strict result:", nonStrictDemo(5, 10)); delete globalThis.total; }
catch (error) { console.log("Non-strict error:", error.name); }
// Strict mode rejects duplicate parameters with SyntaxError.
try { Function('"use strict"; return function(a, a) { return a; };'); }
catch (error) { console.log("Strict duplicate-parameter error:", error.name); }
// Strict mode also forbids undeclared assignments and deleting unqualified identifiers.
function correctDemo(first, second) {
    "use strict";
    let total = 10;
    console.log(`Correct ES6 version: ${first}, ${second}, total=${total}`);
}
correctDemo(5, 10);
