"use strict";
// var is hoisted and initialized as undefined; function declarations are hoisted.
console.log("Score before assignment:", score);
announce();
var score = 50;
function announce() { console.log("Game started"); }
// let stays in the temporal dead zone until initialized, so call after declaration.
let status = "ready";
function startGame() { console.log("Status:", status); }
startGame();
// Arrow functions are assigned to const and should be called after initialization.
const startGameArrow = () => console.log("Arrow status:", status);
startGameArrow();
// Debug: inspect score before assignment and status after initialization.
