"use strict";
const rawData = ['{"user":"Alex","age":25}','{"id":2}','{invalid}','{"user":"Mina","age":"22"}'];
const cleanData = [], errors = [];
for (let i = 0; i < rawData.length; i++) {
    try {
        // Breakpoint here helps inspect rawData[i] and parsed control flow.
        const parsed = JSON.parse(rawData[i]);
        if (!Object.hasOwn(parsed, "user") || !Object.hasOwn(parsed, "age")) throw new Error("Missing user or age key");
        parsed.age = Number(parsed.age);
        if (Number.isNaN(parsed.age)) throw new Error("Invalid age");
        cleanData.push(parsed);
    } catch (error) { errors.push({line:i+1,message:error.message}); console.log(`Line ${i+1}: ${error.message}`); }
}
console.log("Clean data:", cleanData);
console.log("Under 18:", cleanData.filter(person => person.age < 18));
console.log("Errors:", errors);
