"use strict";
const operations = ["add","divide","power","root","subtract"];
const num1 = 25, num2 = 0;
class InvalidOperationError extends Error { constructor(message) { super(message); this.name = "InvalidOperationError"; } }
function calculate(operation, a, b) {
    switch (operation) {
        case "add": return a + b;
        case "divide": if (b === 0) throw new RangeError("Cannot divide by zero"); return a / b;
        case "power": return Math.pow(a, b);
        case "root": if (a < 0) throw new RangeError("Square root of negative number"); return Math.sqrt(a);
        case "subtract": return a - b;
        default: throw new InvalidOperationError("Unknown operation: " + operation);
    }
}
for (const operation of operations) {
    try { console.log(`${operation}: ${calculate(operation, num1, num2)}`); }
    catch (error) { console.log(`${operation} error: ${error.name} - ${error.message}`); }
}
try { calculate("root", -9, 0); } catch (error) { console.log("Root test:", error.message); }
try { calculate("multiply", num1, num2); } catch (error) { console.log("Operation test:", error.name); }
