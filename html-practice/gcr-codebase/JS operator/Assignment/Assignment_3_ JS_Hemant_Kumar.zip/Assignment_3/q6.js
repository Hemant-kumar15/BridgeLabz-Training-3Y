"use strict";
const input = ""; // Set to a number to change the limit; blank means 5.
const limit = input.trim() === "" ? 5 : Math.max(1, Number(input));
for (let row = 1; row <= limit; row++) {
    let pattern = "";
    for (let column = 1; column <= row; column++) pattern += "* ";
    console.log(pattern.trim());
}
// Debug row/column in VS Code. var is function-scoped and reused; let is block-scoped.
// Strict mode throws ReferenceError for an undeclared loop variable.
