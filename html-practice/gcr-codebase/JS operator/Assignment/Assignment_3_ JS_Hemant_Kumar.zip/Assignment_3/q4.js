"use strict";
function showMessage() {
    // Undeclared assignment throws ReferenceError in strict mode; declare the variable.
    let greeting = "Welcome";
    console.log(greeting);
}
showMessage();
// Debug: set a breakpoint on let greeting, add greeting to Watch, and inspect Call Stack.
