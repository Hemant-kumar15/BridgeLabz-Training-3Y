"use strict";
const transactions = [{id:1,amount:2000},{id:2,amount:-500},{id:3},null];
const valid = [], invalid = [];
for (const transaction of transactions) {
    try {
        // Set a VS Code breakpoint here to inspect transaction.
        if (transaction === null) throw new TypeError("Null transaction");
        if (transaction.id === undefined || transaction.amount === undefined) throw new Error("Missing amount or id");
        if (transaction.amount < 0) throw new RangeError("Negative amount");
        valid.push(transaction);
    } catch (error) { invalid.push({transaction, type:error.name, message:error.message}); }
}
console.log("Valid:", valid, "Invalid:", invalid);
console.log(`Successful: ${valid.length}, Failed: ${invalid.length}`);
