"use strict";
const apiData = ["25", "true", "false", "NaN", " ", "100px", "3.14", null, undefined];
const validNumbers = [], invalidNumbers = [];
for (let i = 0; i < apiData.length; i++) {
    const value = apiData[i], numberValue = Number(value);
    console.log(`Item ${i+1}: Number=${numberValue}, Boolean=${Boolean(value)}, String=${String(value)}`);
    if (value === " " || value === "100px" || Number.isNaN(numberValue)) invalidNumbers.push(value);
    else validNumbers.push(numberValue);
}
console.log("Valid numbers:", validNumbers);
console.log("Invalid values:", invalidNumbers);
